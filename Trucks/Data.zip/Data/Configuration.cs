﻿namespace Trucks.Data
{
    public class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-7QAPP3E\SQLEXPRESS;Database=Trucks;Trusted_Connection=True";
    }
}